//
//  TriviaGameView.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/25/25.
//

import SwiftUI

struct TriviaGameView: View {
    let options: TriviaOptions
    @State private var triviaQuestions: [TriviaQuestion] = []
    // Store user selections – one per question, using the question's index
    @State private var userSelections: [Int: String] = [:]
    @State private var showScore = false
    @State private var score: Int = 0

    var body: some View {
        VStack {
            List {
                ForEach(triviaQuestions.indices, id: \.self) { index in
                    // Pass a binding for the selected answer so that the parent view knows about the user’s choice
                    QuestionCardView(question: triviaQuestions[index],
                                     selectedAnswer: Binding(
                                        get: { userSelections[index] },
                                        set: { userSelections[index] = $0 }
                                     )
                    )
                    .padding(.vertical, 8)
                }
            }
            .listStyle(PlainListStyle())

            Button("Submit Answers") {
                // Calculate score with a completion handler approach
                calculateScore { calculatedScore in
                    score = calculatedScore
                    showScore = true
                }
            }
            .padding()
            .alert("Your Score: \(score)", isPresented: $showScore) {
                Button("OK", role: .cancel) { }
            }
        }
        .onAppear {
            fetchTrivia()
        }
        .navigationTitle("Trivia Game")
    }
    
    private func fetchTrivia() {
        //https://opentdb.com/api.php? amount=10 &category=21 &difficulty=medium &type=multiple
        var urlString = "https://opentdb.com/api.php?amount=\(options.numberOfQuestions)"
        
        if let category = options.category {
            urlString += "&category=\(category)"
        }
        if options.difficulty.lowercased() != "any" {
            urlString += "&difficulty=\(options.difficulty)"
        }
        
        if options.type.lowercased() != "any"{
            urlString += "&type=\(options.type)"
        }
        
        let url = URL(string: urlString)!
        print(url)
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let triviaResponse = try JSONDecoder().decode(TriviaResponse.self, from: data)
                triviaQuestions = triviaResponse.results
            } catch {
                print("Error fetching trivia: \(error.localizedDescription)")
            }
        }
    }
    
    private func calculateScore(completion: (Int) -> Void) {
        var calculatedScore = 0
        for (index, question) in triviaQuestions.enumerated() {
            if let userAnswer = userSelections[index], userAnswer == question.correctAnswer {
                calculatedScore += 1
            }
        }
        completion(calculatedScore)
    }
}

