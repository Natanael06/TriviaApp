//
//  QuestionsView.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/24/25.
//

import SwiftUI

import SwiftUI

struct QuestionCardView: View {
    let question: TriviaQuestion
    @State private var shuffledAnswers: [String] = []
    
    @Binding var selectedAnswer: String?
        
    init(question: TriviaQuestion, selectedAnswer: Binding<String?>) {
        self.question = question
        self._selectedAnswer = selectedAnswer
        //self.shuffledAnswers = (question.incorrectAnswers + [question.correctAnswer]).shuffled()
    }
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Display the question text
            Text(question.question)
                .font(.headline)
                .padding(.bottom, 8)
            
            // Display each answer as a button
            ForEach(shuffledAnswers, id: \.self) { answer in
                Button(action: {
                    selectedAnswer = answer
                }) {
                    HStack {
                        Text(answer)
                            .foregroundColor(.primary)
                        Spacer()
                        // Show a checkmark if this answer is selected
                        if selectedAnswer == answer {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.blue)
                        }
                    }
                    .padding()
            
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(selectedAnswer == answer ? Color.blue : Color.gray, lineWidth: 2)
                    )
                    .contentShape(Rectangle())
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding()
        .background(Color(UIColor.secondarySystemBackground))
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
        .onAppear {
            // Shuffle only once when the view appears
            if shuffledAnswers.isEmpty {
                shuffledAnswers = (question.incorrectAnswers + [question.correctAnswer]).shuffled()
            }
        }
    }
}



