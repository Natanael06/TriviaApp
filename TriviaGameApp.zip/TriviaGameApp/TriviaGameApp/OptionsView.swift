//
//  OptionsView.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/26/25.
//

import SwiftUI

struct Category: Identifiable, Hashable {
    let id: Int
    let name: String
}

struct OptionsView: View {
    @State private var numberOfQuestions: Int = 10
    @State private var selectedCategory: Category? = nil
    @State private var selectedDifficulty: String = "Any"
    @State private var selectedType: String = "Any"
    
    let categories: [Category] = [
         Category(id: 9, name: "General Knowledge"),
         Category(id: 10, name: "Entertainment: Books"),
         Category(id: 11, name: "Entertainment: Film"),
         Category(id: 12, name: "Entertainment: Music"),
         Category(id: 13, name: "Entertainment: Musicals & Theatres"),
         Category(id: 14, name: "Entertainment: Television"),
         Category(id: 15, name: "Entertainment: Video Games"),
         Category(id: 16, name: "Entertainment: Board Games"),
         Category(id: 17, name: "Science & Nature"),
         Category(id: 18, name: "Science: Computers"),
         Category(id: 19, name: "Science: Mathematics"),
         Category(id: 20, name: "Mythology"),
         Category(id: 21, name: "Sports"),
         Category(id: 22, name: "Geography"),
         Category(id: 23, name: "History"),
         Category(id: 24, name: "Politics"),
         Category(id: 25, name: "Art"),
         Category(id: 26, name: "Celebrities"),
         Category(id: 27, name: "Animals"),
         Category(id: 28, name: "Vehicles"),
         Category(id: 29, name: "Entertainment: Comics"),
         Category(id: 30, name: "Science: Gadgets"),
         Category(id: 31, name: "Entertainment: Japanese Anime & Manga"),
         Category(id: 32, name: "Entertainment: Cartoon & Animations")
     ]

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Number of Questions")) {
                    Stepper("\(numberOfQuestions)", value: $numberOfQuestions, in: 1...50)
                }
                
                Section(header: Text("Category")) {
                    Picker("Category", selection: $selectedCategory) {
                        Text("Any Category").tag(Category?.none)
                        ForEach(categories) { category in
                            Text(category.name).tag(Category?.some(category))
                        }
                    }
                }
                Section(header: Text("Difficulty")) {
                    Picker("Difficulty", selection: $selectedDifficulty) {
                        Text("Any").tag("any")
                        Text("Easy").tag("easy")
                        Text("Medium").tag("medium")
                        Text("Hard").tag("hard")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
                
                Section(header: Text("Type")) {
                    Picker("Type", selection: $selectedType) {
                        Text("Any").tag("any")
                        Text("Multiple Choice").tag("multiple")
                        Text("True/False").tag("boolean")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
                
                //Navigate to the game view when ready
                NavigationLink("Start Trivia Game", destination: TriviaGameView(options: TriviaOptions(numberOfQuestions: numberOfQuestions, category: selectedCategory?.id, difficulty: selectedDifficulty, type: selectedType)))
            }
            .navigationTitle("Trivia Options")
        }
    }
}

struct TriviaOptions {
    let numberOfQuestions: Int
    let category: Int?  // Optional so that "Any" can be represented as nil
    let difficulty: String
    let type: String
}


#Preview {
    OptionsView()
}
