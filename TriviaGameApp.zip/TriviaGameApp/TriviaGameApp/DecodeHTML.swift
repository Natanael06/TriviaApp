//
//  DecodeHTML.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/23/25.
//
import Foundation

@propertyWrapper
struct HTMLDecoded: Codable {
    var wrappedValue: String
    
    init(wrappedValue: String) {
        self.wrappedValue = wrappedValue.htmlDecoded
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let decodedString = try container.decode(String.self)
        wrappedValue = decodedString.htmlDecoded
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(wrappedValue)
    }
}

extension String {
    var htmlDecoded: String {
        guard let data = data(using: .utf8) else { return self }
        do {
            let attributed = try NSAttributedString(
                data: data,
                options: [
                    .documentType: NSAttributedString.DocumentType.html,
                    .characterEncoding: String.Encoding.utf8.rawValue
                ],
                documentAttributes: nil
            )
            return attributed.string
        } catch {
            print("Error decoding HTML: \(error)")
            return self
        }
    }
}
