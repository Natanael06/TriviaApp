//
//  TriviaGameAppApp.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/22/25.
//

import SwiftUI

@main
struct TriviaGameAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
