//
//  TriviaResponse.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/23/25.
//

import Foundation

struct TriviaResponse: Codable {
    let results: [TriviaQuestion]
}

struct TriviaQuestion: Codable {
    @HTMLDecoded var difficulty: String
    @HTMLDecoded var correctAnswer: String
    // If the incorrect answers are also HTML encoded, you can decode them like this:
    var incorrectAnswers: [String]
    @HTMLDecoded var type: String
    @HTMLDecoded var category: String
    @HTMLDecoded var question: String
    enum CodingKeys: String, CodingKey {
        case difficulty
        case correctAnswer = "correct_answer"
        case incorrectAnswers = "incorrect_answers"
        case type
        case category
        case question
    }

    // Custom init to process incorrectAnswers if needed
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        _difficulty = try container.decode(HTMLDecoded.self, forKey: .difficulty)
        _correctAnswer = try container.decode(HTMLDecoded.self, forKey: .correctAnswer)
        let answers = try container.decode([String].self, forKey: .incorrectAnswers)
        // Optionally, decode HTML for each incorrect answer
        incorrectAnswers = answers.map { $0.htmlDecoded }
        _type = try container.decode(HTMLDecoded.self, forKey: .type)
        _category = try container.decode(HTMLDecoded.self, forKey: .category)
        _question = try container.decode(HTMLDecoded.self, forKey: .question)
    }
}


