//
//  ContentView.swift
//  TriviaGameApp
//
//  Created by NATANAEL  MEDINA  on 3/22/25.
//

import SwiftUI
struct ContentView: View {
    
    var body: some View {
        OptionsView()
    }
    
}

#Preview {
    ContentView()
}
