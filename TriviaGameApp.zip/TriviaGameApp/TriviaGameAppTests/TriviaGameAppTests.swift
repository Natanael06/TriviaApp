//
//  TriviaGameAppTests.swift
//  TriviaGameAppTests
//
//  Created by NATANAEL  MEDINA  on 3/22/25.
//

import Testing
@testable import TriviaGameApp

struct TriviaGameAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
